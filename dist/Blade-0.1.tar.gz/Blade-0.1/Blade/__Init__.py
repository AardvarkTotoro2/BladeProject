import pygame, random, math, time, os

from pygame.locals import *

from BladeMain import BladeMain

Main()
